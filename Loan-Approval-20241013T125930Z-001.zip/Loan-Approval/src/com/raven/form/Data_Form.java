package com.raven.form;

import com.formdev.flatlaf.FlatClientProperties;
import com.formdev.flatlaf.FlatDarkLaf;
import com.formdev.flatlaf.FlatLaf;
import com.formdev.flatlaf.FlatLightLaf;
import com.formdev.flatlaf.extras.FlatAnimatedLafChange;
import com.formdev.flatlaf.extras.FlatSVGIcon;
import com.formdev.flatlaf.fonts.roboto.FlatRobotoFont;
import com.formdev.flatlaf.themes.FlatMacDarkLaf;
import com.formdev.flatlaf.themes.FlatMacLightLaf;
import com.raven.chart.ModelChart;
import com.raven.component.Form;
import com.raven.theme.ThemeColorChange;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.text.DecimalFormat;
import java.util.Random;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;

import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import net.miginfocom.swing.MigLayout;

public class Data_Form extends Form {

    public Data_Form() {
        try {
            if(ThemeColorChange.getInstance().getMode() == ThemeColorChange.Mode.LIGHT){
            UIManager.setLookAndFeel(new FlatLightLaf());
            FlatAnimatedLafChange.showSnapshot();
                FlatMacLightLaf.setup();

                FlatAnimatedLafChange.hideSnapshotWithAnimation();
            }
            else{
            UIManager.setLookAndFeel(new FlatDarkLaf());
             FlatAnimatedLafChange.showSnapshot();
                FlatMacDarkLaf.setup();
               
                FlatAnimatedLafChange.hideSnapshotWithAnimation();
            }
        } catch (UnsupportedLookAndFeelException e) {
            e.printStackTrace();
        }
        FlatRobotoFont.install();
        FlatLaf.registerCustomDefaultsSource("com/raven/form");
        UIManager.put("defaultFont", new Font(FlatRobotoFont.FAMILY, Font.PLAIN, 13));
        
        initComponents();
        chart1.addLegend("Approved", new Color(135, 189, 245));
        chart1.addLegend("Declined", new Color(189, 135, 245));
        chart1.addData(new ModelChart("January", new double[]{500, 200}));
        chart1.addData(new ModelChart("February", new double[]{600, 750}));
        chart1.addData(new ModelChart("March", new double[]{200, 350}));
        chart1.addData(new ModelChart("April", new double[]{480, 150}));
        chart1.addData(new ModelChart("May", new double[]{350, 540}));
        chart1.addData(new ModelChart("June", new double[]{190, 580}));
        chart1.addData(new ModelChart("July", new double[]{190, 280}));
        chart1.addData(new ModelChart("August", new double[]{232, 900}));
        chart1.addData(new ModelChart("September", new double[]{680, 350}));
        chart1.addData(new ModelChart("October", new double[]{248, 500}));
        chart1.addData(new ModelChart("November", new double[]{420, 350}));
        chart1.addData(new ModelChart("December", new double[]{670, 1000}));
    }

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        chart1 = new com.raven.chart.Chart();

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(73, 73, 73)
                .addComponent(chart1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(236, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(chart1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(357, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.raven.chart.Chart chart1;
    // End of variables declaration//GEN-END:variables

    
}


