/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.raven.swing;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import javax.swing.border.AbstractBorder;
/**
 *
 * @author Admin
 */
public class RoundedBorder extends AbstractBorder {

    private final int cornerRadius;

    public RoundedBorder(int cornerRadius) {
        this.cornerRadius = cornerRadius;
    }

    @Override
    public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
        Graphics2D g2d = (Graphics2D) g; // Cast to use advanced features
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON); // Enable smoother edges
        g2d.drawRoundRect(x, y, width - 1, height - 1, cornerRadius, cornerRadius);
    }
}

